<?php
date_default_timezone_set('UTC');

  //connexion à la base de données
  $con = mysqli_connect("localhost","root","","bts");
  if(!$con){
     echo "Vous n'êtes pas connecté à la base de donnée";
  }
?>