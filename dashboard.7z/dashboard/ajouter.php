<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
    if (isset($_POST['button'])) {
        extract($_POST);
        if (!empty($username) && !empty($password) && !empty($status) && !empty($plaque1) ) {
            include_once "connexion.php";
            $req = mysqli_query($con, "INSERT INTO easyportal VALUES(NULL, '$username', '$password','$status','$plaque1','$plaque2','$plaque3','$plaque4','$plaque5')");
            if ($req) {
                header("location: index.php");
                exit;
            } else {
                $message = "Employé non ajouté";
            }
        } else {
            $message = "Veuillez remplir tous les champs !";
        }
    }
    ?>

    <div class="form">
        <a href="index.php" class="back_btn"><img src="images/back.png"> Retour</a>
        <h2>Ajouter un utilisateur</h2>
        <p class="erreur_message">
            <?php
            if (isset($message)) {
                echo $message;
            }
            ?>
        </p>
        <form action="" method="POST">
            <label>Username</label>
            <input type="text" name="username">
            <label>Password</label>
            <input type="text" name="password">
            <label>Status</label>
            <input type="text" name="status">
            <label>Plaque1</label>
            <input type="text" name="plaque1">
            <label>Plaque2</label>
            <input type="text" name="plaque2">
            <label>Plaque3</label>
            <input type="text" name="plaque3">
            <label>Plaque4</label>
            <input type="text" name="plaque4">
            <label>Plaque5</label>
            <input type="text" name="plaque5">
            <input type="submit" value="Ajouter" name="button">
        </form>
    </div>
</body>
</html>
