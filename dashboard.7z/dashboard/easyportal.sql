

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT *!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bts`
--

-- --------------------------------------------------------

--
-- Structure de la table `easyportal`
CREATE TABLE IF NOT EXISTS `easyportal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `plaque1` char(30) NOT NULL,
  `plaque2` char(30) NOT NULL,
  `plaque3` char(30) NOT NULL,
  `plaque4` char(30) NOT NULL,
  `plaque5` char(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `easyportal`
--

INSERT INTO `easyportal` (`id`, `name`, `password`, `status`, `plaque1`, `plaque2`, `plaque3`, `plaque4`, `plaque5`) VALUES
(1, 'Irfan Arhama', 'az1234er', 'ty5678ui', 'xxxxxxx', 'xxxxxxxx', 'xxxxxxx'),
(2, 'Irfan Arhama', 'az1234er', 'ty5678ui', 'xxxxxxx', 'xxxxxxxx', 'xxxxxxx'),
(3, 'Irfan Arhama', 'az1234er', 'ty5678ui', 'xxxxxxx', 'xxxxxxxx', 'xxxxxxx'),
(4, 'Irfan Arhama', 'az1234er', 'ty5678ui', 'xxxxxxx', 'xxxxxxxx', 'xxxxxxx');

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;