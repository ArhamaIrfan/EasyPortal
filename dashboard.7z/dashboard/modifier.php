<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php

// Connexion à la base de données
include_once "connexion.php";

// Récupérer l'ID depuis le lien
$id = $_GET['id'];

// Requête pour afficher les informations d'un employé
$req = mysqli_query($con, "SELECT * FROM easyportal WHERE id = $id");
$row = mysqli_fetch_assoc($req);

// Vérifier si le bouton "Ajouter" a été cliqué
if (isset($_POST['button'])) {
    // Extraction des informations envoyées dans des variables via la méthode POST
    extract($_POST);
    
    // Vérifier que tous les champs ont été remplis
    if (!empty($username) && !empty($password) && !empty($status) && !empty($plaque1) && !empty($plaque2) && !empty($plaque3) && !empty($plaque4) && !empty($plaque5)) {
        // Requête de modification
        $req = mysqli_query($con, "UPDATE easyportal SET username = '$username', password = '$password', status = '$status', plaque1 = '$plaque1', plaque2 = '$plaque2', plaque3 = '$plaque3', plaque4 = '$plaque4', plaque5 = '$plaque5' WHERE id = $id");
        
        if ($req) { // Si la requête a été effectuée avec succès, on effectue une redirection
            header("location: index.php");
            exit;
        } else { // Si non
            $message = "Employé non modifié";
        }
    } else {
        // Si non, afficher un message d'erreur
        $message = "Veuillez remplir tous les champs !";
    }
}

?>

<div class="form">
    <a href="index.php" class="back_btn"><img src="images/back.png"> Retour</a>
    <h2>Modifier l'employé : <?=$row['username']?></h2>
    <p class="erreur_message">
        <?php
        if (isset($message)) {
            echo $message;
        }
        ?>
    </p>
    <form action="" method="POST">
        <label>Username</label>
        <input type="text" name="username">
        <label>Password</label>
        <input type="text" name="password">
        <label>Status</label>
        <input type="text" name="status">
        <label>Plaque1</label>
        <input type="text" name="plaque1">
        <label>Plaque2</label>
        <input type="text" name="plaque2">
        <label>Plaque3</label>
        <input type="text" name="plaque3">
        <label>Plaque4</label>
        <input type="text" name="plaque4">
        <label>Plaque5</label>
        <input type="text" name="plaque5">
        <input type="submit" value="Modifier" name="button">
    </form>
</div>
</body>
</html>
